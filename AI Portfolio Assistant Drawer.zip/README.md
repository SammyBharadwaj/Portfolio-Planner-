
  # AI Portfolio Assistant Drawer

  This is a code bundle for AI Portfolio Assistant Drawer. The original project is available at https://www.figma.com/design/LIsBEMij92lafQhJl1rUsf/AI-Portfolio-Assistant-Drawer.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  